const api=window.companion,$=s=>document.querySelector(s);
const cat=new CatSprite($('#pet-avatar'),()=>{},{idle:false});
let watching=false;
let chatStatus='ready';
function updateStatus(){$('#pet-state').textContent=watching?'● Watching':chatStatus;$('#pet-state').classList.toggle('watch-status',watching);}
function showWatch(state){watching=!!state?.active;const button=$('#pet-watch');button.textContent=watching?'Stop watching':'Watch screen';button.title=watching?'Stop watching '+(state?.sourceName||'your screen'):'Choose a screen or window to watch';button.setAttribute('aria-label',button.textContent);button.setAttribute('aria-pressed',String(watching));button.classList.toggle('watching',watching);updateStatus();if(state?.error)say('Watching stopped: '+state.error);}
const say=text=>{$('#pet-response').textContent=text;};
async function action(name){try{const r=await api.action(name);if(!r.ok)say(r.error);}catch{say('Could not connect. Please restart Neko.');}}
api.state().then(result=>{if(result.ok){$('#pet-name').textContent=result.data.settings.name;showWatch(result.data.watch);$('#pet-mute').textContent=result.data.muted?'Unmute':'Mute';}else say(result.error);});
api.on(event=>{
 if(event.type==='watch-state')showWatch(event.state);
 if(event.type==='play'){cat.set('playful','bounce');say('Hehe. Your move!');}
 if(event.type==='reply'){cat.speaking=false;cat.set(event.emotion,event.motion);say(event.reply);}
 if(event.type==='status'){chatStatus=event.status;updateStatus();$('#pet-send').disabled=event.status==='thinking';cat.busy=event.status==='thinking';if(cat.busy){cat.set('thinking');say('Thinking of a reply…');}}
 if(event.type==='frame'){cat.frame(event.frame);}
 if(event.type==='chat-error')say(event.message);
 if(event.type==='stop'){chatStatus='ready';updateStatus();}
 if(event.type==='pet'){if(!cat.busy){cat.set('affectionate','bounce');say('Mrrrp. That’s the spot. ♡');}}
 if(event.type==='settings')$('#pet-name').textContent=event.state.settings.name;
 if(event.type==='muted')$('#pet-mute').textContent=event.muted?'Unmute':'Mute';
});
$('#pet-form').onsubmit=async e=>{e.preventDefault();const text=$('#pet-input').value.trim();if(!text)return;$('#pet-send').disabled=true;$('#pet-input').value='';try{const result=await api.chat(text);if(!result.ok){say(result.error);$('#pet-input').value=text;}}catch{say('Could not send. Please restart Neko.');$('#pet-input').value=text;}finally{$('#pet-send').disabled=false;}};
$('#pet-chat').onclick=()=>action('open-chat');$('#pet-settings').onclick=()=>action('open-settings');$('#pet-mute').onclick=()=>action('toggle-mute');$('#pet-face').onclick=()=>action('pet');$('#pet-quit').onclick=()=>action('quit');

$('#pet-watch').onclick=async()=>{if(!watching){await action('open-watch');return;}const button=$('#pet-watch');button.disabled=true;try{const result=await api.watchStop();if(result.ok)showWatch(result.data);else say(result.error);}catch{say('Could not stop watching. Quit Neko to stop all capture.');}finally{button.disabled=false;}};
$('#pet-face').oncontextmenu=e=>{e.preventDefault();action('play');};
