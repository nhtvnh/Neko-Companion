/* Original procedural sound design. No recordings, speech service, or network. */
(function(root){
  const SR=24000, TAU=Math.PI*2;
  const moods={neutral:1,happy:1.08,excited:1.2,laughing:1.14,sad:.8,annoyed:.9,surprised:1.24,curious:1.05,listening:.98,thinking:.95,sleepy:.72};
  function chatter(text,emotion='happy'){
    const glyphs=Array.from(String(text).slice(0,600));
    const count=Math.max(4,Math.min(32,Math.ceil(glyphs.length/7)));
    const syllables=[];let cursor=.12;
    for(let i=0;i<count;i++){
      const from=Math.floor(i*glyphs.length/count),to=Math.floor((i+1)*glyphs.length/count);
      const chunk=glyphs.slice(from,to).join(''),code=glyphs[from]?.codePointAt(0)||97;
      const length=.20+(code%4)*.022;
      const gap=/[!?…]/.test(chunk)?.42:/[.,;:\n]/.test(chunk)?.30:i%4===3?.27:.09;
      if(cursor+length+gap>17.5)break;
      const pitch=(300+(code%9)*21)*(moods[emotion]||1);
      const vowel=code%4;
      // Only matching forward-looking mouth poses; avoid the sideways eyes
      // in frames 6/8, which made rapid full-face swaps look like jitter.
      const previous=syllables.at(-1);
      const afterPause=!previous||cursor-(previous.start+previous.duration)>=.22;
      const frame=i%4===1&&gap<.22&&!afterPause&&i<count-1?7:9;
      syllables.push({start:cursor,duration:length,pitch,vowel,frame});
      cursor+=length+gap;
    }
    const mouthCues=[{start:0,frame:5}];
    function cue(start,frame){if(mouthCues.at(-1).frame!==frame)mouthCues.push({start,frame});}
    syllables.forEach((s,i)=>{cue(s.start,s.frame);const next=syllables[i+1];if(!next||next.start-s.start-s.duration>=.22)cue(s.start+s.duration,5);});
    const samples=new Float32Array(Math.ceil((cursor+.18)*SR));
    const formants=[[730,1450],[420,2100],[540,980],[350,1200]];
    for(const s of syllables){
      let phase=0;
      const n=Math.floor(s.duration*SR),offset=Math.floor(s.start*SR);
      for(let j=0;j<n;j++){
        const t=j/n;
        // Soft voiced syllable with a small falling pitch; no intelligible speech.
        const f=s.pitch*(1.08-.19*t+.018*Math.sin(TAU*2*t));phase+=TAU*f/SR;
        const env=Math.min(1,t/.12)*Math.min(1,(1-t)/.19);
        let value=0;
        for(let h=1;h<=10;h++){
          const hz=h*f;const [f1,f2]=formants[s.vowel];
          const weight=(.2+1.1*Math.exp(-(((hz-f1)/260)**2))+.65*Math.exp(-(((hz-f2)/370)**2)))/h;
          value+=Math.sin(phase*h)*weight;
        }
        samples[offset+j]+=Math.tanh(value*1.7)*env*.28;
      }
    }
    return{sampleRate:SR,samples,syllables,mouthCues,duration:samples.length/SR};
  }
  const scores={
    happy:[[0,620,890,.13],[.13,890,1180,.19]],
    excited:[[0,620,900,.10],[.10,930,1300,.10],[.2,1300,1600,.22]],
    laughing:[[0,900,560,.11],[.13,1020,650,.11],[.26,1150,720,.13]],
    sad:[[0,630,490,.20],[.22,440,300,.27]],
    annoyed:[[0,230,180,.16],[.18,220,140,.16]],
    surprised:[[0,450,1450,.20],[.22,1550,1100,.13]],
    curious:[[0,620,880,.14],[.17,760,1230,.23]],
    thinking:[[0,440,480,.10],[.19,590,620,.12]],
    sleepy:[[0,530,330,.37]],
    listening:[[0,600,850,.16]],
    neutral:[[0,750,630,.12]],
    ready:[[0,660,820,.10],[.11,880,1100,.17]],
    error:[[0,380,270,.16],[.20,300,200,.18]],
    saved:[[0,740,980,.10],[.11,1100,1400,.16]],
    pet:[[0,530,1100,.15],[.16,800,1500,.18]]
  };
  function effect(name='happy'){
    const notes=scores[name]||scores.neutral;
    const duration=Math.max(...notes.map(n=>n[0]+n[3]))+.04;
    const samples=new Float32Array(Math.ceil(duration*SR));
    for(const [start,from,to,length]of notes){let phase=0;const n=Math.floor(length*SR),offset=Math.floor(start*SR);for(let i=0;i<n;i++){const t=i/n;const f=from+(to-from)*(1-(1-t)**2);phase+=TAU*f/SR;const env=Math.min(1,t/.06)*(1-t)**1.8;samples[offset+i]+=(Math.sin(phase)+.16*Math.sin(phase*2.01))*env*.24;}}
    return{sampleRate:SR,samples,duration};
  }
  function mouthFrameAt(sound,seconds){let frame=5;for(const cue of sound.mouthCues){if(cue.start>seconds)break;frame=cue.frame;}return frame;}
  const design={chatter,effect,mouthFrameAt};if(typeof module==='object'&&module.exports)module.exports=design;else root.NekoSoundDesign=design;
})(typeof window==='object'?window:globalThis);
