const $=selector=>document.querySelector(selector);
const api=window.companion;
const cat=new CatSprite($('#avatar'),index=>api?.frame(index),{onEmotion:emotion=>$('#emotion').textContent=emotion});
let state,busy=false,muted=false,watchState={active:false,inFlight:false},screenChoices=[],patCount=0,availableModels=[];
const player=new NekoSoundPlayer(cat,playing=>{$('#stop-button').hidden=!playing&&!busy;if(playing)$('#status').textContent='Chattering…';else if(!busy)$('#status').textContent='Ready when you are';});
const form=$('#settings-form');
const audioSettings=()=>({...state?.settings,volume:muted?0:(state?.settings.volume??0)});
function showNotice(text,settings=false){const el=$(settings?'#settings-notice':'#notice');el.textContent=text;el.hidden=!text;}
async function call(promise){const result=await promise;if(!result.ok)throw new Error(result.error);return result.data;}
function updateState(next){state=next;if(next.watch)updateWatch(next.watch);muted=next.muted??muted;$('#cat-name').textContent=state.settings.name;$('#active-model').textContent='Model: '+state.settings.model;$('#message-input').placeholder=`Say something to ${state.settings.name}…`;$('#connection').textContent=state.settings.demo?'Demo mode':state.hasOpenAI?'Ready to chat':'Add an API key';updateMute();if(state.warning)showNotice(state.warning);}
function updateMute(){$('#sound-label').textContent=muted?'Muted':state?.settings.soundsEnabled||state?.settings.sfxEnabled?'Sounds on':'Sounds off';$('#mute-button').textContent=muted?'Unmute':'Mute';}
function message(role,text){$('#welcome')?.remove();const row=document.createElement('div');row.className=`message ${role}`;const label=document.createElement('div');label.className='message-label';label.textContent=role==='user'?'YOU':role==='error'?'COULD NOT SEND':(state?.settings.name||'NEKO').toUpperCase();const bubble=document.createElement('div');bubble.className='bubble';bubble.textContent=text;row.append(label,bubble);$('#messages').append(row);$('#messages').scrollTop=$('#messages').scrollHeight;return row;}
function setBusy(value){busy=value;cat.busy=value||watchState.inFlight;$('#send-button').disabled=value;$('#stop-button').hidden=!value&&!player.playing;}
async function ensureState(){if(!state)updateState(await call(api.state()));return state;}
async function send(text){if(busy)return;text=text.trim();if(!text)return;try{await ensureState();player.stop();showNotice('');$('#message-input').value='';setBusy(true);await call(api.chat(text));}catch(error){showNotice(error.message);$('#message-input').value=text;}finally{setBusy(false);$('#message-input').focus();}}

const starterModels=['gpt-4.1-mini','gpt-4.1','gpt-5-mini'];
function renderModels(value){
 const ids=[...new Set([...starterModels,...availableModels])];
 $('#model-choice').replaceChildren(...ids.map(id=>new Option(id,id)),new Option('Custom model ID…','__custom__'));
 $('#model-choice').value=ids.includes(value)?value:'__custom__';
 $('#custom-model-row').hidden=ids.includes(value);form.elements.model.value=value;
}
$('#model-choice').onchange=()=>{const custom=$('#model-choice').value==='__custom__';$('#custom-model-row').hidden=!custom;if(custom)form.elements.model.focus();else form.elements.model.value=$('#model-choice').value;};
$('#load-models').onclick=async()=>{const button=$('#load-models');button.disabled=true;$('#model-status').textContent='Loading models…';try{availableModels=await call(api.models());renderModels(form.elements.model.value);$('#model-status').textContent=availableModels.length+' models returned by your saved key. Choose a chat model, then save.';}catch(error){$('#model-status').textContent=error.message;}finally{button.disabled=false;}};
$('#active-model').onclick=()=>$('#settings-button').click();
function openSettings(){for(const [name,value]of Object.entries(state.settings)){const input=form.elements.namedItem(name);if(!input)continue;if(input.type==='checkbox')input.checked=value;else input.value=value;}renderModels(state.settings.model);$('#model-status').textContent='Saved model: '+state.settings.model;form.elements.openai.value='';form.elements.clearOpenAI.checked=false;$('#openai-status').textContent=state.hasOpenAI?'Key available · leave blank to keep':'No key saved';$('#key-storage').textContent=state.secureStorage?'Your OpenAI key is encrypted using your operating system’s secure storage.':'Secure key storage is unavailable. Your key stays in memory for this session; re-enter it after restarting.';showNotice('',true);$('#settings-dialog').showModal();}
form.addEventListener('submit',async event=>{event.preventDefault();const settings={};for(const name of Object.keys(state.settings)){const input=form.elements.namedItem(name);if(input)settings[name]=input.type==='checkbox'?input.checked:input.type==='range'?Number(input.value):input.value;}try{updateState(await call(api.save({settings,keys:{openai:form.elements.openai.value},clearKeys:form.elements.clearOpenAI.checked?['openai']:[]})));form.elements.openai.value='';$('#settings-dialog').close();showNotice('Settings saved.');player.stop();player.effect('saved',audioSettings());}catch(error){showNotice(error.message,true);}});
function previewSettings(){return{...state.settings,volume:Number(form.elements.volume.value),soundsEnabled:form.elements.soundsEnabled.checked,sfxEnabled:form.elements.sfxEnabled.checked};}
$('#test-chatter').onclick=()=>{cat.set('happy');player.talk('Mrrp! A little curious, a little silly, and happy to be here.', 'happy', previewSettings());};
$('#test-effects').onclick=()=>{player.stop();cat.set('happy','bounce');player.effect('happy',previewSettings());};
$('#chat-form').onsubmit=e=>{e.preventDefault();send($('#message-input').value);};
$('#message-input').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send(e.target.value);}};
document.querySelectorAll('.suggestions button').forEach(btn=>btn.onclick=()=>send(btn.textContent));
$('#settings-button').onclick=async()=>{try{await ensureState();openSettings();}catch(error){showNotice(error.message);}};
$('#close-settings').onclick=()=>{player.stop();$('#settings-dialog').close();};
$('#minimize-button').onclick=()=>api.action('hide-chat');
$('#play-button').onclick=()=>api.action('play');
$('#quit-button').onclick=()=>api.action('quit');
$('#stop-button').onclick=()=>{player.stop();api.action('stop');};
$('#pet-button').onclick=()=>api.action('pet');
$('#clear-button').onclick=async()=>{if(!confirm('Clear the conversation saved on this device? Your memory notes and settings will stay.'))return;try{player.stop();await call(api.clearHistory());}catch(error){showNotice(error.message);}};
async function toggleMute(){try{await call(api.mute(!muted));}catch(error){showNotice(error.message);}}
$('#mute-button').onclick=toggleMute;
for(const emotion of ['happy','affectionate','shy','playful','curious','confused','inspired','surprised','worried','annoyed','sleepy','sad','crying','yawning','skeptical','unimpressed','shocked','smug']){const button=document.createElement('button');button.textContent=emotion;button.onclick=()=>{if(!state||busy||player.playing)return;cat.set(emotion,emotion==='happy'?'bounce':'tilt');$('#emotion').textContent=emotion;player.effect(emotion,audioSettings());};$('#expressions').append(button);}
function updateWatch(value){
 watchState=value||{active:false,inFlight:false};
 const active=watchState.active;
 $('#watch-indicator').textContent=active?'● WATCHING':'WATCHING OFF';$('#watch-indicator').classList.toggle('watch-active',active);
 $('#watch-quick-stop').hidden=!active;$('#watch-stop').disabled=!active;$('#watch-now').disabled=!active||watchState.inFlight;$('#watch-start').disabled=active;
 $('#watch-status').textContent=watchState.error?'Stopped: '+watchState.error:active?(watchState.inFlight?'Looking at ':'Watching ')+watchState.sourceName+' · every '+watchState.interval+' seconds':'Watching is off. It never starts automatically.';
 cat.busy=busy||watchState.inFlight;
 if(watchState.inFlight&&!busy&&!player.playing){cat.set('thinking');$('#status').textContent='Looking at your screen…';}
 else if(!busy&&!player.playing)$('#status').textContent='Ready when you are';
}
async function openWatch(){try{await ensureState();if(!$('#settings-dialog').open)openSettings();$('#watch-section').scrollIntoView?.({block:'start'});}catch(error){showNotice(error.message);}}
$('#watch-open').onclick=openWatch;
$('#watch-refresh').onclick=async()=>{const button=$('#watch-refresh');button.disabled=true;try{screenChoices=await call(api.watchSources());$('#watch-source').replaceChildren(new Option('Choose a source…',''),...screenChoices.map(s=>new Option(s.name,s.id)));$('#watch-preview').hidden=true;showNotice(screenChoices.length?'Choose a source, then press Start watching.':'No sources available. Restore the window you want to share.',true);}catch(error){showNotice(error.message,true);}finally{button.disabled=false;}};
$('#watch-source').onchange=()=>{const source=screenChoices.find(s=>s.id===$('#watch-source').value);$('#watch-preview').hidden=!source;if(source)$('#watch-preview').src=source.preview;};
$('#watch-start').onclick=async()=>{try{updateWatch(await call(api.watchStart({sourceId:$('#watch-source').value,interval:Number($('#watch-interval').value)})));showNotice('',true);}catch(error){showNotice(error.message,true);}};
async function stopWatch(){try{updateWatch(await call(api.watchStop()));player.stop();}catch(error){showNotice(error.message,true);}}
$('#watch-stop').onclick=stopWatch;$('#watch-quick-stop').onclick=stopWatch;
$('#watch-now').onclick=async()=>{try{await call(api.watchNow());}catch(error){showNotice(error.message,true);}};
if(api){api.on(event=>{
  if(event.type==='status'){setBusy(event.status==='thinking');if(event.status==='thinking'){$('#status').textContent='Thinking of a reply…';cat.set('thinking');player.effect('thinking',audioSettings());}else if(!player.playing)$('#status').textContent='Ready when you are';}
  if(event.type==='reply'){const row=message('assistant',event.reply);if(event.origin==='screen')row.querySelector('.message-label').textContent=(state?.settings.name||'NEKO')+' · SCREEN';cat.set(event.emotion,event.motion);$('#emotion').textContent=event.emotion;if(state)player.talk(event.reply,event.emotion,audioSettings());}
  if(event.type==='user-message'){player.stop();showNotice('');message('user',event.text);}
  if(event.type==='chat-error'){message('error',event.message);cat.set('neutral');if(state)player.effect('error',audioSettings());}
  if(event.type==='watch-state')updateWatch(event.state);
  if(event.type==='open-watch')openWatch();
  if(event.type==='play'){if(!state||busy||player.playing)return;cat.set('playful','bounce');player.effect('excited',audioSettings());}
  if(event.type==='open-settings')$('#settings-button').click();
  if(event.type==='toggle-mute')toggleMute();
  if(event.type==='muted'){muted=event.muted;player.stop();updateMute();}
  if(event.type==='stop'){player.stop();$('#status').textContent='Stopped';}
  if(event.type==='settings')updateState(event.state);
  if(event.type==='history-cleared'){$('#messages').replaceChildren();cat.set('neutral');showNotice('Conversation cleared.');}
  if(event.type==='pet'){if(!state||busy||player.playing)return;const emotion=['affectionate','shy','happy'][patCount++%3];cat.set(emotion,'bounce');player.effect('pet',audioSettings());}
});call(api.state()).then(next=>{updateState(next);for(const item of state.history)message(item.role,item.content);if(!state.hasOpenAI&&!state.settings.demo)showNotice('Try the sounds in Settings, or enable Demo mode. Add your OpenAI key for real conversation.');}).catch(error=>showNotice(error.message));}
else{showNotice('Launch Neko with the Windows app or desktop launcher.');$('#send-button').disabled=true;$('#settings-button').disabled=true;}
