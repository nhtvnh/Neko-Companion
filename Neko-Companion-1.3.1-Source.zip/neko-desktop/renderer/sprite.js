(() => {
 const map={neutral:0,halfblink:1,blink:2,looking:3,lookingup:4,tilted:4,closed:5,small:6,wide:7,round:8,talk:9,calm:10,smile:10,happy:11,laughing:11,inspired:12,affectionate:13,shy:14,sad:15,crying:16,annoyed:17,surprised:18,curious:19,confused:19,thinking:20,sleepy:21,yawning:22,excited:23,worried:24,skeptical:25,unimpressed:26,playful:27,shocked:28,smug:29,listening:3};
 // The supplied sheet has uneven gutters; these are its measured boundaries.
 const columns=[0,313,618,922,1229,1536],rows=[0,262,517,772,1024,1276,1536];
 class CatSprite {
  constructor(element,onFrame=()=>{},options={}){
   this.element=element;this.onFrame=onFrame;this.onEmotion=options.onEmotion||(()=>{});this.emotion='neutral';this.speaking=false;this.busy=false;this.holdUntil=Date.now()+9000;this.idleIndex=0;
   // A single loaded SVG image, clipped in source pixels, avoids percentage
   // background rounding and transient empty tiles at Windows display scaling.
   const ns='http://www.w3.org/2000/svg';
   this.art=document.createElementNS(ns,'svg');this.art.setAttribute('viewBox','0 0 307.2 256');this.art.setAttribute('preserveAspectRatio','xMidYMid meet');this.art.classList.add('sprite-art');this.art.setAttribute('aria-hidden','true');
   const paper=document.createElementNS(ns,'rect');paper.setAttribute('width','307.2');paper.setAttribute('height','256');paper.setAttribute('fill','#ffffff');this.art.append(paper);
   this.tile=document.createElementNS(ns,'svg');this.tile.setAttribute('width','307.2');this.tile.setAttribute('height','256');this.tile.setAttribute('preserveAspectRatio','xMidYMid meet');this.tile.setAttribute('overflow','hidden');
   const sheet=document.createElementNS(ns,'image');sheet.setAttribute('href','assets/cat-sheet.jpg');sheet.setAttributeNS('http://www.w3.org/1999/xlink','xlink:href','assets/cat-sheet.jpg');sheet.setAttribute('width','1536');sheet.setAttribute('height','1536');this.tile.append(sheet);this.art.append(this.tile);this.element.replaceChildren(this.art);this.frame(0);
   if(options.idle!==false){
    this.blinkTimer=setInterval(()=>{if(this.speaking||this.busy)return;this.frame(2);setTimeout(()=>{if(!this.speaking&&!this.busy)this.frame(map[this.emotion]??0);},150);},4700);
    this.idleTimer=setInterval(()=>this.idleTick(),1000);
   }
  }
  idleTick(now=Date.now()){
   if(this.speaking||this.busy||now<this.holdUntil)return false;
   const choices=['looking','lookingup','calm','halfblink','neutral','sleepy','yawning'];
   let next=choices[this.idleIndex++%choices.length];if(next===this.emotion)next=choices[this.idleIndex++%choices.length];
   this.set(next,next==='lookingup'?'tilt':'none');this.holdUntil=now+9000+Math.random()*4000;return true;
  }
  frame(index){
   if(!Number.isInteger(index)||index<0||index>29)return;
   // Trim one source pixel on each edge to avoid neighbouring-cell seams.
   const col=index%5,row=Math.floor(index/5);
   this.tile.setAttribute('viewBox',`${columns[col]+1} ${rows[row]+1} ${columns[col+1]-columns[col]-2} ${rows[row+1]-rows[row]-2}`);
   this.element.dataset.frame=String(index);this.onFrame(index);
  }
  set(emotion,motion='none'){
   this.emotion=emotion in map?emotion:'neutral';this.holdUntil=Date.now()+10000;if(!this.speaking)this.frame(map[this.emotion]);this.onEmotion(this.emotion);this.element.setAttribute('aria-label',`Cat, ${this.emotion} expression`);
   this.art.classList.remove('nod','bounce','tilt');clearTimeout(this.motionTimer);
   if(['nod','bounce','tilt'].includes(motion)){this.art.classList.remove('breathing');void this.element.offsetWidth;this.art.classList.add(motion);this.motionTimer=setTimeout(()=>{this.art.classList.remove(motion);this.art.classList.add('breathing');},1100);}else this.art.classList.add('breathing');
  }
  rest(){this.speaking=false;this.holdUntil=Date.now()+10000;this.frame(map[this.emotion]??0);}
 }
 window.CatSprite=CatSprite;
})();
