class NekoSoundPlayer {
  constructor(cat,onPlaying=()=>{}){this.cat=cat;this.onPlaying=onPlaying;this.context=null;this.sources=new Set();this.epoch=0;this.playing=false;this.raf=null;}
  async contextReady(){this.context??=new AudioContext();if(this.context.state!=='running')await this.context.resume();return this.context;}
  async playBuffer(sound,volume,epoch){const context=await this.contextReady();if(epoch!==this.epoch)return;const buffer=context.createBuffer(1,sound.samples.length,sound.sampleRate);buffer.copyToChannel(sound.samples,0);const source=context.createBufferSource(),gain=context.createGain();gain.gain.value=Math.max(0,Math.min(1,volume));source.buffer=buffer;source.connect(gain);gain.connect(context.destination);this.sources.add(source);source.onended=()=>{this.sources.delete(source);source.disconnect();gain.disconnect();};source.start();return context.currentTime;}
  async effect(name,settings){if(!settings.sfxEnabled||settings.volume===0)return;const epoch=this.epoch;try{await this.playBuffer(NekoSoundDesign.effect(name),settings.volume,epoch);}catch{/* Muted/unavailable audio never blocks chat. */}}
  async talk(text,emotion,settings){
    this.stop();const epoch=this.epoch;const sound=NekoSoundDesign.chatter(text,emotion);
    if(!settings.soundsEnabled)sound.samples.fill(0);
    if(settings.sfxEnabled){const intro=NekoSoundDesign.effect(emotion);const combined=new Float32Array(intro.samples.length+sound.samples.length);combined.set(intro.samples);combined.set(sound.samples,intro.samples.length);sound.samples=combined;sound.syllables.forEach(s=>s.start+=intro.duration);sound.mouthCues.forEach(c=>c.start+=intro.duration);sound.duration+=intro.duration;}
    this.playing=true;this.onPlaying(true);this.cat.speaking=true;
    let audioStart=null;
    if((settings.soundsEnabled||settings.sfxEnabled)&&settings.volume>0){try{audioStart=await this.playBuffer(sound,settings.volume,epoch);}catch{}}
    if(epoch!==this.epoch)return;
    const start=performance.now();let lastFrame=-1;
    const tick=()=>{if(epoch!==this.epoch)return;const seconds=audioStart!=null?(this.context.currentTime-audioStart):(performance.now()-start)/1000;if(seconds>=sound.duration){this.stop();return;}
      const frame=NekoSoundDesign.mouthFrameAt(sound,seconds);
      if(frame!==lastFrame){this.cat.frame(frame);lastFrame=frame;}this.raf=requestAnimationFrame(tick);
    };tick();
  }
  stop(){this.epoch++;cancelAnimationFrame(this.raf);for(const source of this.sources){source.onended=null;try{source.stop();source.disconnect();}catch{}}this.sources.clear();this.playing=false;this.cat.rest();this.onPlaying(false);}
}
window.NekoSoundPlayer=NekoSoundPlayer;
