# Version 1.3.1 validation

Passed:

- 27 Node tests: OpenAI structured chat and vision contracts, image inclusion, refusal/error handling, bounded context, encrypted keys and migration, IPC trust, procedural audio, and all supported response emotions.
- Watch lifecycle regressions: off by default, explicit source/interval, duplicate suppression, busy-chat deferral, cancellation during capture (no upload), cancellation during API response (no late comment), and stop on unavailable source.
- Timing regressions: syllables last at least 200 ms, pose changes do not produce sub-180 ms flashes after the initial lead-in, short gaps hold an open pose, and long pauses close the mouth.
- Model regressions: saved/custom IDs survive store restart, are sent in both chat and vision requests, listing safely parses IDs, and API errors do not expose echoed secrets.
- Main DOM integration with simulated IPC and Web Audio: settings open/save, topmost checkbox payload, safe chat rendering, synchronized talking frames, Stop, previews, Mute, pats, history, idle/busy behavior, source selection/preview, watch start/stop indicators, model selection, model-list loading, custom ID save/reopen, and failed-list recovery.
- Floating DOM integration: text input, replies, Settings, Mute, error display, shared frames, and the relocated watch button, active status through chat status changes, direct stop, and frame 29 coordinates.
- SVG render verification: all 30 frames at 100%, 125%, 150%, and 200% portrait widths; no blank tiles, no transparent output pixels, all crop coordinates stay inside the image and follow measured, uneven gutters. Contact sheet visually inspected for neighbouring-row strips. Invalid frame indices retain the current frame. Uses resvg with the app’s white portrait background.
- Supplied 30-frame (5×6) sheet verified as 1536×1536 JPEG (corrected mislabeled PNG extension); bundled font metadata identifies Pixelify Sans.

BUILD-INFO.txt records final executable archive integrity, source-byte checks and SHA256.

Native Windows execution, real screen capture/OS permissions, actual speaker output, display scaling, dragging, and always-on-top behavior cannot be verified in this environment. DOM tests use simulated IPC/Web Audio and do not replace a native runtime test. Live OpenAI chat and image inference remain untested without a usable API key. The executable is unsigned.
