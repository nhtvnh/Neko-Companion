const { app, BrowserWindow, ipcMain, safeStorage, screen, globalShortcut, desktopCapturer, powerMonitor } = require('electron');
const path = require('node:path');
const { trustedSender } = require('./ipc-trust.cjs');
const { think, analyzeScreen, listModels } = require('./core.cjs');
const { ScreenWatcher } = require('./watch.cjs');
const { createStore } = require('./store.cjs');
let panel, pet, store, controller, busy = false, muted = false, watcher, screenChat = false;
let sourceChoices=new Map();
app.setName('Neko Companion');
function broadcast(data) { for (const win of [panel, pet]) if (win && !win.isDestroyed()) win.webContents.send('companion-event',data); }
function allowed(event) { return trustedSender(event,[{win:panel,file:path.join(__dirname,'../renderer/index.html')},{win:pet,file:path.join(__dirname,'../renderer/pet.html')}]); }
function handle(channel, fn) { ipcMain.handle(channel, async (e,...args) => { if (!allowed(e)) return {ok:false,error:'Access denied.'}; try { return {ok:true,data:await fn(...args)}; } catch(error) { return {ok:false,error:error.message || 'Something went wrong.'}; } }); }
function secureWindow(options, file) {
  const win = new BrowserWindow({...options,webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,backgroundThrottling:false,autoplayPolicy:'no-user-gesture-required'}});
  win.webContents.setWindowOpenHandler(() => ({action:'deny'}));
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.on('will-attach-webview', e => e.preventDefault());
  win.webContents.session.setPermissionRequestHandler((_wc,_permission,cb) => cb(false));
  win.loadFile(path.join(__dirname,'../renderer',file));
  return win;
}
function showPanel() { panel.show(); panel.focus(); }
function cancel() { controller?.abort(); watcher?.stop(); broadcast({type:'stop'}); }
function stopWatching(){const state=watcher.stop();if(screenChat)controller?.abort();return state;}
function setPetOnTop(value){if(pet&&!pet.isDestroyed())pet.setAlwaysOnTop(value,'screen-saver');}
function setup() {
  store = createStore(app.getPath('userData'),safeStorage);
  panel = secureWindow({width:1020,height:780,minWidth:800,minHeight:630,backgroundColor:'#f6f3ed',title:'Neko Companion',autoHideMenuBar:true},'index.html');
  const area = screen.getPrimaryDisplay().workArea;
  pet = secureWindow({width:320,height:485,x:area.x+area.width-340,y:area.y+area.height-505,frame:false,transparent:true,resizable:false,alwaysOnTop:store.settings.alwaysOnTop,skipTaskbar:false,hasShadow:false,title:'Neko — desktop companion'},'pet.html');
  setPetOnTop(store.settings.alwaysOnTop);
  pet.setVisibleOnAllWorkspaces(true,{visibleOnFullScreen:true});
  pet.on('closed', () => { pet=null; });
  panel.on('close', e => { if (!app.quitting && pet) { e.preventDefault(); panel.hide(); } });
  watcher=new ScreenWatcher({
    capture:async id=>{
      const sources=await desktopCapturer.getSources({types:[id.startsWith('screen:')?'screen':'window'],thumbnailSize:{width:1280,height:720},fetchWindowIcons:false});
      const source=sources.find(x=>x.id===id);if(!source||source.thumbnail.isEmpty())throw new Error('The selected screen or window is unavailable. Restore it or choose another source.');
      return 'data:image/jpeg;base64,'+source.thumbnail.toJPEG(75).toString('base64');
    },
    analyze:(image,last,signal)=>analyzeScreen(store.settings,store.history,image,last,store.key('openai'),signal),
    isBusy:()=>busy,
    onState:state=>broadcast({type:'watch-state',state}),
    onReply:answer=>{store.append('[Screen reaction]',answer.reply);broadcast({type:'reply',...answer,origin:'screen'});}
  });
  powerMonitor.on('lock-screen',()=>stopWatching());
  powerMonitor.on('suspend',()=>stopWatching());
  handle('models',()=>listModels(store.key('openai')));
  handle('watch-sources',async()=>{
    const sources=await desktopCapturer.getSources({types:['screen','window'],thumbnailSize:{width:320,height:180},fetchWindowIcons:false});
    const ownTitles=new Set([panel.getTitle(),pet?.getTitle()]);
    const choices=sources.filter(x=>!ownTitles.has(x.name)&&!x.thumbnail.isEmpty());
    sourceChoices=new Map(choices.map(x=>[x.id,{id:x.id,name:x.name}]));
    return choices.map(x=>({id:x.id,name:x.name,preview:x.thumbnail.toDataURL()}));
  });
  handle('watch-start',config=>{
    if(busy)throw new Error('Wait for the current reply before starting screen watching.');
    if(!store.key('openai'))throw new Error('Save an OpenAI key first.');
    if(store.settings.demo)throw new Error('Turn off Demo mode and save first.');
    const source=sourceChoices.get(config?.sourceId);if(!source)throw new Error('Refresh the list and choose a screen or window.');
    return watcher.start(source,config.interval);
  });
  handle('watch-stop',()=>stopWatching());
  handle('watch-now',()=>watcher.tick(true));
  globalShortcut.register('CommandOrControl+Shift+M',showPanel);
  handle('state', () => ({...store.publicState(),muted,watch:watcher.state()}));
  handle('mute', value => {if(typeof value!=='boolean')throw new Error('Invalid mute value.');muted=value;broadcast({type:'muted',muted});return muted;});
  handle('save', payload => { if (busy) throw new Error('Wait for the current reply or press Stop before saving.'); if (!payload || typeof payload !== 'object') throw new Error('Invalid settings.'); const state=store.update(payload); setPetOnTop(state.settings.alwaysOnTop);if(state.settings.demo||!state.hasOpenAI)stopWatching(); broadcast({type:'settings',state}); return state; });
  handle('chat', async message => {
    if (busy) throw new Error('A reply is already in progress.');
    if(typeof message!=='string'||!message.trim()||message.length>4000)throw new Error('Write a message between 1 and 4,000 characters.');
    message=message.trim();
    broadcast({type:'user-message',text:message});
    watcher.interrupt();
    busy=true; controller=new AbortController(); const signal=controller.signal;
    const settings={...store.settings};
    broadcast({type:'status',status:'thinking'});
    try {
      screenChat=watcher.active&&!settings.demo;
      const image=screenChat?await watcher.snapshot(signal):undefined;
      const answer = await think(settings,store.history,message,store.key('openai'),signal,undefined,image);
      if(signal.aborted) throw new Error('Request cancelled.');
      store.append(message,answer.reply);
      broadcast({type:'reply',...answer});
      return answer;
    } catch(error) {broadcast({type:'chat-error',message:error.message,text:message});throw error;}
    finally {busy=false;controller=null;screenChat=false;broadcast({type:'status',status:'ready'});}
  });
  handle('clear-history', () => { if(busy) throw new Error('Stop the current reply before clearing history.');store.clear();broadcast({type:'history-cleared'}); });
  handle('action', name => {
    if(name==='open-chat') showPanel();
    else if(name==='open-settings') {showPanel();panel.webContents.send('companion-event',{type:'open-settings'});}
    else if(name==='open-watch') {showPanel();panel.webContents.send('companion-event',{type:'open-watch'});}
    else if(name==='toggle-mute') {panel.webContents.send('companion-event',{type:'toggle-mute'});}
    else if(name==='hide-chat') panel.hide();
    else if(name==='stop') cancel();
    else if(name==='quit') {app.quitting=true;app.quit();}
    else if(name==='pet') broadcast({type:'pet'});
    else if(name==='play') broadcast({type:'play'});
    else throw new Error('Unknown action.');
  });
  ipcMain.on('frame',(event,value)=>{ if(!allowed(event) || event.sender.id !== panel.webContents.id || !Number.isInteger(value) || value<0 || value>29) return; if(pet) pet.webContents.send('companion-event',{type:'frame',frame:value}); });
}
if (!app.requestSingleInstanceLock()) app.quit();
else { app.on('second-instance',()=>panel&&showPanel()); app.whenReady().then(setup); }
app.on('before-quit',()=>{app.quitting=true;controller?.abort();watcher?.stop();});
app.on('will-quit',()=>globalShortcut.unregisterAll());
app.on('window-all-closed',()=>app.quit());
app.on('activate',()=>panel&&showPanel());
