const path=require('node:path');
const {fileURLToPath}=require('node:url');
function canonicalFile(url,platform=process.platform){
  try{const parsed=new URL(url);if(parsed.protocol!=='file:'||parsed.hostname||parsed.username||parsed.password)return null;
    const filename=fileURLToPath(parsed,{windows:platform==='win32'});
    return platform==='win32'?path.win32.normalize(filename).toLowerCase():path.posix.normalize(filename);
  }catch{return null;}
}
function trustedSender(event,windows,platform=process.platform){
  try{return windows.some(({win,file})=>{
    if(!win||win.isDestroyed()||!event.senderFrame)return false;
    const wc=win.webContents,frame=event.senderFrame,main=wc.mainFrame;
    // Electron frame wrappers need not have stable JavaScript object identity.
    if(event.sender.id!==wc.id||frame.processId!==main.processId||frame.routingId!==main.routingId)return false;
    const expected=platform==='win32'?path.win32.normalize(file).toLowerCase():path.posix.normalize(file);
    return canonicalFile(frame.url,platform)===expected;
  });}catch{return false;}
}
module.exports={canonicalFile,trustedSender};
