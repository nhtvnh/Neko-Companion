const {createHash}=require('node:crypto');
class ScreenWatcher {
 constructor({capture,analyze,isBusy=()=>false,onState=()=>{},onReply=()=>{},delay=setTimeout,clear=clearTimeout}){Object.assign(this,{capture,analyze,isBusy,onState,onReply,delay,clear});this.active=false;this.inFlight=false;this.generation=0;this.timer=null;this.abort=null;this.source=null;this.interval=30;this.lastHash='';this.lastComment='';this.lastSeenAt=null;this.error='';}
 state(){return{active:this.active,sourceName:this.source?.name||'',interval:this.interval,inFlight:this.inFlight,lastSeenAt:this.lastSeenAt,error:this.error};}
 emit(){this.onState(this.state());}
 start(source,interval){if(!source||typeof source.id!=='string'||!['screen','window'].includes(source.id.split(':')[0]))throw new Error('Choose a screen or window first.');if(![15,30,60,120].includes(interval))throw new Error('Choose a supported interval.');this.stop();this.source={id:source.id,name:source.name};this.interval=interval;this.lastHash='';this.lastComment='';this.lastSeenAt=null;this.error='';this.active=true;this.emit();this.schedule(0);return this.state();}
 schedule(ms=this.interval*1000){this.clear(this.timer);if(this.active)this.timer=this.delay(()=>{if(this.active)void this.tick().catch(()=>{});},ms);}
 interrupt(){this.generation++;this.abort?.abort();}
 stop(){this.active=false;this.clear(this.timer);this.timer=null;this.interrupt();this.emit();return this.state();}
 async snapshot(signal){if(!this.active)throw new Error('Screen watching is off.');const source=this.source.id,generation=this.generation;const image=await this.capture(source);if(!this.active||this.source.id!==source||generation!==this.generation||signal?.aborted)throw new Error('Screen capture cancelled.');return image;}
 async tick(force=false){
  if(!this.active)throw new Error('Start screen watching first.');
  if(this.inFlight||this.isBusy()){this.schedule();return this.state();}
  this.clear(this.timer);this.inFlight=true;const generation=this.generation;const controller=new AbortController();this.abort=controller;this.emit();
  try{const image=await this.snapshot(controller.signal);const hash=createHash('sha256').update(image).digest('hex');this.lastSeenAt=new Date().toISOString();if(!force&&hash===this.lastHash)return this.state();
   const result=await this.analyze(image,this.lastComment,controller.signal);
   if(!this.active||generation!==this.generation||controller.signal.aborted)return this.state();
   this.lastHash=hash;if(result.shouldComment){this.lastComment=result.reply;this.onReply(result);}
  }catch(error){if(this.active&&generation===this.generation&&!controller.signal.aborted){this.error=error.message||'Screen watching failed.';this.active=false;}}
  finally{this.inFlight=false;if(this.abort===controller)this.abort=null;this.emit();this.schedule();}
  return this.state();
 }
}
module.exports={ScreenWatcher};
