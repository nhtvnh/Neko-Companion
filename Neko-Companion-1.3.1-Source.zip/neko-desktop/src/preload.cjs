const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('companion', {
  models: () => ipcRenderer.invoke('models'),
  watchSources: () => ipcRenderer.invoke('watch-sources'),
  watchStart: config => ipcRenderer.invoke('watch-start',config),
  watchStop: () => ipcRenderer.invoke('watch-stop'),
  watchNow: () => ipcRenderer.invoke('watch-now'),
  mute: value => ipcRenderer.invoke('mute',value),
  state: () => ipcRenderer.invoke('state'),
  save: payload => ipcRenderer.invoke('save', payload),
  chat: text => ipcRenderer.invoke('chat', text),
  clearHistory: () => ipcRenderer.invoke('clear-history'),
  action: name => ipcRenderer.invoke('action', name),
  frame: value => ipcRenderer.send('frame', value),
  on: callback => { const handler = (_event, data) => callback(data); ipcRenderer.on('companion-event', handler); return () => ipcRenderer.removeListener('companion-event',handler); }
});
