const fs = require('node:fs');
const path = require('node:path');
const { DEFAULTS, cleanSettings } = require('./core.cjs');
function createStore(directory, safeStorage) {
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
  const file = path.join(directory, 'companion.json');
  let data = { settings: { ...DEFAULTS }, secrets: {}, history: [] };
  let warning = '';
  if (fs.existsSync(file)) { try { const raw = JSON.parse(fs.readFileSync(file,'utf8')); data.settings = cleanSettings(raw.settings || {}); data.secrets = raw.secrets || {}; data.history = Array.isArray(raw.history) ? raw.history.filter(x => ['user','assistant'].includes(x.role) && typeof x.content === 'string' && x.content.length <= 5000).slice(-100) : []; } catch { warning = 'Saved settings could not be read. Defaults were loaded.'; } }
  // Retire the unused ElevenLabs credential when upgrading from version 1.
  if (data.secrets.elevenlabs) { delete data.secrets.elevenlabs; save(); }
  const session = {};
  const secure = () => safeStorage.isEncryptionAvailable() && !(process.platform === 'linux' && safeStorage.getSelectedStorageBackend() === 'basic_text');
  function save() { const temp = `${file}.tmp`; fs.writeFileSync(temp, JSON.stringify(data,null,2), {mode:0o600}); fs.renameSync(temp,file); }
  function key(name) { if (name in session) return session[name]; if (data.secrets[name] && secure()) { try { return safeStorage.decryptString(Buffer.from(data.secrets[name],'base64')); } catch { warning = 'A saved key could not be unlocked. Please enter it again.'; } } return ''; }
  return {
    get settings() { return data.settings; }, get history() { return data.history; },
    get warning() { return warning; }, key,
    publicState() { const hasOpenAI = !!key('openai'); return {settings:data.settings,history:data.history,hasOpenAI,secureStorage:secure(),warning}; },
    update(payload) {
      const settings = cleanSettings(payload.settings, data.settings);
      const changes = {};
      for (const name of ['openai']) {
        const value = payload.keys?.[name];
        if (value !== undefined && (typeof value !== 'string' || value.length > 1000 || /[\r\n]/.test(value))) throw new Error('Invalid API key.');
        if (payload.clearKeys?.includes(name)) changes[name] = '';
        else if (value?.trim()) changes[name] = value.trim();
      }
      for (const [name,value] of Object.entries(changes)) {
        session[name] = value;
        if (secure() && value) data.secrets[name] = safeStorage.encryptString(value).toString('base64'); else delete data.secrets[name];
      }
      data.settings = settings; save(); return this.publicState();
    },
    append(message, reply) { data.history.push({role:'user',content:message},{role:'assistant',content:reply}); data.history = data.history.slice(-100); save(); },
    clear() { data.history = []; save(); }
  };
}
module.exports = { createStore };
