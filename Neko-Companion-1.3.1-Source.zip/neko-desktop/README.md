# Neko Companion 1.3.1 — Windows portable app

Download **Neko-Companion-1.3.1-Windows-x64.exe** and double-click it on a Windows x64 computer. No Node.js installation, terminal, or installer is needed. The first launch may take a few seconds while the bundled app extracts into your temporary directory. Settings and chat history persist in your user profile.

The executable is unsigned. Windows may show an unknown-publisher warning. It does not request administrator privileges. It has been built and structurally inspected here; launching it on Windows was not possible in this environment.

## Get started

1. Run the EXE. Click the cat to pat it, or use the expression buttons.
2. Open **Settings** and click **Try talking sound** and **Try happy effect** to preview sounds.
3. Enable **Demo mode** and save to try a sample conversation without an API key.
4. For real conversations, enter your **OpenAI API key**, disable Demo mode, and save. The default model is `gpt-4.1-mini`; you may choose another Responses-compatible model supporting Structured Outputs that your account can access.

Get a key from [OpenAI API keys](https://platform.openai.com/api-keys). Enter it only in Neko's password field. OpenAI API usage requires account access and credits. No key is bundled in this app.

## What changed in 1.3.1

- Fixed the portrait fit: the cat now fills the card width, with one stable 6:5 viewport in both windows. The corner window is taller to accommodate the full portrait.
- Replaced percentage-based background sprites with a single SVG image clipped using source-pixel coordinates. Crops follow the supplied sheet’s measured, uneven row and column boundaries; a one-pixel inset avoids neighbouring tile seams. Each frame preserves its aspect ratio. The portrait panel stays opaque while gentle motion stays inside it.
- Corrected the supplied image's extension: its bytes are JPEG, even though the upload was named PNG. Artwork pixels are unchanged.
- Slowed chatter syllables from roughly 62–114 milliseconds to 200–266 milliseconds. Added phrase and punctuation pauses, and removed tiny closed-mouth flashes between nearby syllables.
- Talking now uses forward-looking closed/small/open poses (5, 9, 7), avoiding side-looking and half-blinking faces from the speaking row. Mouth poses are held at least 180 milliseconds after the initial lead-in; short gaps hold the pose and longer pauses close the mouth.
- Reduced idle and reaction movement to keep the portrait steady. Model selection, Pixelify Sans, watch controls, always-on-top, API key storage, and history remain.

## Change the AI model

1. Open **Settings → AI model & API key** at the top.
2. Select a model from the **AI model** dropdown. Starter choices are shortcuts, not a guarantee of access. **Load my models** retrieves model IDs using your saved API key; first save a new key if needed.
3. For another model, choose **Custom model ID…** and type the exact ID.
4. Click **Save settings**. The model shown in the chat footer updates. Subsequent chat and screen requests use it, and the setting persists after restarting.

Neko uses the Responses API with Structured Outputs for reply/emotion JSON. Screen watching additionally requires image input. The Models API lists IDs and basic information, not a complete capability matrix, so account-list entries can include models unsuitable for Neko. A model that rejects the request format or image input produces an error asking you to select another model. There is no silent fallback to GPT-4.1 mini. Demo mode produces local sample replies regardless of model selection.

## Watch your screen

1. Save a usable OpenAI key and disable Demo mode. Use a model supporting image input and Structured Outputs; the default is `gpt-4.1-mini`.
2. Click **Watch screen** on the corner window or **Watch my screen** in chat.
3. Press **Choose screen / window**, select a source, and review its preview. Choosing a single window limits what you share.
4. Choose an interval (15, 30, 60, or 120 seconds), then **Start watching**. You can close Settings afterward. **Look now** requests an immediate check when Neko is free.
5. While watching, typed messages include a fresh snapshot of the selected source, so you can ask about what is visible.
6. Use **Stop watching** in either window before opening private content. Watching also stops when the computer locks/suspends, on a capture/API error, or when Neko quits. It never resumes automatically after restarting.

This sends snapshots to OpenAI and uses paid image-input API requests. It is periodic visual analysis, not continuous video or audio. Neko can choose to stay quiet when nothing useful has changed. Byte-identical captures skip an extra automatic request. Moving screens or Neko's overlay may still cause new requests. Only one automatic request runs at a time; typed chat takes priority. Stop cancels pending requests and prevents later reactions; it cannot recall a snapshot already sent.

Screenshots are JPEGs captured at up to a 1280×720 thumbnail request size. Small text can be hard to read. Minimized, protected, or exclusive fullscreen windows may be unavailable or blank; try a restored window or borderless mode. The AI can misinterpret visible content and cannot control your computer.

## Desktop controls

- Drag the name bar to move the cat.
- **Chat** opens the chat window.
- **Ctrl+Shift+M** opens chat while Neko is running.
- Click the cat or **Give a little head pat** for an affectionate reaction.
- **—** in chat hides the chat window and keeps the cat running.
- **Stop** in chat stops sounds, screen watching, and a pending reply.
- **×** on the cat or **Quit Neko** in Settings exits the app.
- **Always keep the corner window on top** changes always-on-top behavior.
- Sound keeps playing when chat is hidden. The app prevents background animation throttling so the floating cat's mouth stays in sync.
- Mute in either window silences all sounds for the current session. The two Settings toggles are persistent.

## Personality and memory

Edit the cat's name, roleplay personality, response language, and **Things to remember** in Settings. The app sends those notes and the last 24 chat messages with each request. Up to 100 messages are saved locally. Older messages are not automatically summarized. Use ↺ to clear the conversation; memory notes remain until you edit them.

The cat uses your supplied 5×6 sheet directly. Rows: neutral/half-blink/blink/side look/upward look; closed/small/wide/round/talking mouth; calm/happy/inspired/affectionate/shy; sad/crying/annoyed/surprised/curious; thinking/sleepy/yawning/excited/worried; skeptical/unimpressed/playful/shocked/smug. The white background is part of the artwork. Responses select expressions through validated JSON output; speech uses the mouth frames and returns to the response emotion afterward. Idle expressions pause while thinking or talking.

## Privacy

Only OpenAI is contacted by the application, for chat, screen reactions, and loading your model list. Requests include your message, recent history, roleplay preferences, and memory notes. Responses use `store: false`; OpenAI's applicable data policies still apply. Sounds are generated locally and no microphone is used. Screen capture starts only after you select a source and press Start. Source previews stay local. While watching, the selected source’s screenshots are sent to OpenAI for reactions and typed chat; screenshots are held in memory and are not saved locally. Reaction text remains in local conversation history. There is no file browsing, computer control, analytics, microphone capture, or messaging to other people.

API requests run in the Electron main process. The isolated renderer never receives a saved key back from storage. OpenAI keys are encrypted using Electron safeStorage and your OS key protection. When secure storage is unavailable, the key stays in memory for the session only.

Settings and conversation text are kept in `%APPDATA%/Neko Companion/companion.json` on Windows. **Conversation and memory text are not encrypted.** Closing the app leaves this history intact. Clear history and remove your key in Settings if needed.

## Troubleshooting

- **No real reply:** disable Demo mode, save an OpenAI key, and check internet access and API credits.
- **401/403:** verify key and account/model permissions.
- **404:** verify the model ID.
- **429:** check API credits or rate limits.
- **No sound:** check the two sound toggles, Neko volume, session Mute, and Windows volume/output. Preview from Settings.
- **Cat seems missing:** check the taskbar or press Ctrl+Shift+M while the app is running.
- **First launch seems slow:** allow the portable executable time to extract. Subsequent launches still use a temporary extracted runtime.

## Source and development

Close the old Neko app using × on the cat before opening this update. Your existing OpenAI key, settings, and history stay in your user profile.

The separate source ZIP is optional. You do not need it to run the EXE.

```sh
npm install
npm start
npm test
npm run dist:win
```

`dist:win` builds the portable Windows x64 executable. Cross-building from Linux is supported by the configured portable target; Windows executable resource customization and signing are disabled because no signing identity is configured. The default Electron icon is used. Windows installers, auto-update, and signing are not part of this build.

macOS/Linux source launchers remain available for development but this release download is a Windows executable. `npm run dist:mac` and `npm run dist:linux` require suitable build environments.

- `src/core.cjs`: OpenAI Responses API and validated model output.
- `src/main.cjs`: desktop windows, cancellation, and IPC validation.
- `src/store.cjs`: local history and encrypted key storage.
- `renderer/sound-design.js`: original deterministic chatter and effects synthesis.
- `renderer/sound-player.js`: local Web Audio playback and mouth timing.
- `renderer/assets/cat-sheet.jpg`: new supplied 30-frame expression sheet.

See VALIDATION.md for completed checks and practical limits.

- `src/watch.cjs`: opt-in capture scheduling, duplicate suppression, and cancellation.
- [OpenAI image input documentation](https://developers.openai.com/api/docs/guides/images-vision)
- [Electron desktopCapturer documentation](https://www.electronjs.org/docs/latest/api/desktop-capturer)

Model listing follows the [OpenAI Models API](https://developers.openai.com/api/reference/resources/models/methods/list). See the [GPT-5 mini model documentation](https://developers.openai.com/api/docs/models/gpt-5-mini) for its supported modalities and response features.

Optional render verification: install `jsdom`, `@resvg/resvg-js`, and `pngjs`, then run `node test/sprite-render.cjs`. It checks all 30 SVG frames at four display widths. This is an SVG rasterization check, not a native Windows screenshot.
