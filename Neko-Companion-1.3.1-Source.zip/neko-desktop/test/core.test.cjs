const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {DEFAULTS,think,parseResponse,cleanSettings,request}=require('../src/core.cjs');
const {createStore}=require('../src/store.cjs');
const envelope=value=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(value)}]}]});
const reply={reply:'Hello, human.',emotion:'curious',motion:'tilt'};
test('OpenAI contract: bounded context, structured emotion, no stored response',async()=>{
  let captured;
  const result=await think(DEFAULTS,Array.from({length:30},(_,i)=>({role:i%2?'assistant':'user',content:String(i)})),'Hi','test-key',undefined,async(url,init)=>{captured={url,...init};return new Response(JSON.stringify(envelope(reply)));});
  assert.deepEqual(result,reply);assert.equal(captured.url,'https://api.openai.com/v1/responses');
  const body=JSON.parse(captured.body);assert.equal(body.store,false);assert.equal(body.input.length,25);assert.equal(body.input.at(-1).content,'Hi');assert.equal(body.text.format.type,'json_schema');assert.equal(body.text.format.strict,true);
});
test('refusals remain readable, invalid or incomplete replies cannot set arbitrary frames',()=>{
  assert.equal(parseResponse({output:[{type:'message',content:[{type:'refusal',refusal:'Cannot do that.'}]}]}).reply,'Cannot do that.');
  assert.throws(()=>parseResponse(envelope({...reply,emotion:'run-command'})),/invalid reply/);
  assert.throws(()=>parseResponse({status:'incomplete'}),/cut short/);
});
test('provider error hides echoed secrets and gives useful status',async()=>{
  await assert.rejects(()=>think(DEFAULTS,[],'Hi','secret',undefined,async()=>new Response('echo secret',{status:401})),/OpenAI error 401. Check your API key/);
});
test('cancelled network requests do not become connection errors',async()=>{
  const controller=new AbortController();controller.abort();
  await assert.rejects(()=>request('https://api.openai.com/v1/responses',{},'OpenAI',controller.signal,async()=>{throw new Error('aborted');}),/cancelled/);
});
test('demo is explicit and never uses a provider',async()=>{const result=await think({...DEFAULTS,demo:true},[],'Hi','',undefined,()=>{throw new Error('should not fetch');});assert.match(result.reply,/sample reply/);});
test('input limits and settings reject invalid types and paths',async()=>{assert.throws(()=>cleanSettings({soundsEnabled:'yes'}),/soundsEnabled/);assert.throws(()=>cleanSettings({volume:NaN}),/volume/);await assert.rejects(()=>think(DEFAULTS,[],'x'.repeat(4001),'key'),/4,000/);});
test('encrypted keys survive restart but never enter public state; remove deletes key',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'neko-test-'));
  const safe={isEncryptionAvailable:()=>true,getSelectedStorageBackend:()=> 'gnome_libsecret',encryptString:s=>Buffer.from([...s].reverse().join('')),decryptString:b=>[...b.toString()].reverse().join('')};
  try{const store=createStore(dir,safe);store.update({settings:{name:'Vin cat'},keys:{openai:'private-test-key'}});assert(!JSON.stringify(store.publicState()).includes('private-test-key'));assert(!fs.readFileSync(path.join(dir,'companion.json'),'utf8').includes('private-test-key'));assert.equal(createStore(dir,safe).key('openai'),'private-test-key');store.update({settings:{},clearKeys:['openai']});assert.equal(store.key('openai'),'');assert.equal(createStore(dir,safe).key('openai'),'');}finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('no secure storage means session-only keys; history can be cleared',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'neko-test-'));
  const safe={isEncryptionAvailable:()=>false};
  try{const store=createStore(dir,safe);store.update({settings:{},keys:{openai:'session-only-secret'}});assert.equal(store.key('openai'),'session-only-secret');assert.equal(createStore(dir,safe).key('openai'),'');assert(!fs.readFileSync(path.join(dir,'companion.json'),'utf8').includes('session-only-secret'));store.append('hello','hi');assert.equal(store.history.length,2);store.clear();assert.equal(createStore(dir,safe).history.length,0);}finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('upgrade removes retired voice credentials and keeps OpenAI and history',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'neko-upgrade-'));
  try{fs.writeFileSync(path.join(dir,'companion.json'),JSON.stringify({settings:{...DEFAULTS,voiceId:'old-voice',voiceEnabled:true},secrets:{elevenlabs:'retired-secret'},history:[{role:'user',content:'hello'}]}));const store=createStore(dir,{isEncryptionAvailable:()=>false});assert.equal(store.history.length,1);assert.equal(store.settings.soundsEnabled,true);assert.equal(store.settings.voiceId,undefined);assert(!fs.readFileSync(path.join(dir,'companion.json'),'utf8').includes('retired-secret'));}finally{fs.rmSync(dir,{recursive:true,force:true});}
});
