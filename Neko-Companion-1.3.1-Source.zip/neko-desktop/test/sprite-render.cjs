// Optional: NEKO_QA_MODULES=/path/to/node_modules node test/sprite-render.cjs
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const dep=name=>require(process.env.NEKO_QA_MODULES?path.join(process.env.NEKO_QA_MODULES,name):name);
const {JSDOM}=dep('jsdom'),{Resvg}=dep('@resvg/resvg-js'),{PNG}=dep('pngjs');
const root=path.join(__dirname,'../renderer'),dom=new JSDOM('<div id="cat"></div>',{runScripts:'outside-only'}),w=dom.window;
w.eval(fs.readFileSync(path.join(root,'sprite.js'),'utf8'));const el=w.document.querySelector('#cat'),cat=new w.CatSprite(el,()=>{},{idle:false});
const data='data:image/jpeg;base64,'+fs.readFileSync(path.join(root,'assets/cat-sheet.jpg')).toString('base64');const previews=[];let renders=0,minCoverage=1;
for(let i=0;i<30;i++){
 cat.frame(i);const box=cat.tile.getAttribute('viewBox').split(' ').map(Number);assert(box[0]>=0&&box[1]>=0&&box[0]+box[2]<=1536&&box[1]+box[3]<=1536);
 const art=cat.art.cloneNode(true);art.querySelector('image').setAttribute('href',data);art.querySelector('image').setAttributeNS('http://www.w3.org/1999/xlink','xlink:href',data);art.setAttribute('width','294');art.setAttribute('height','245');
 const svg=new w.XMLSerializer().serializeToString(art);
 for(const width of [294,368,441,588]){
  const result=new Resvg(svg,{fitTo:{mode:'width',value:width},background:'#ffffff'}).render(),png=PNG.sync.read(result.asPng());let colored=0;
  for(let k=0;k<png.data.length;k+=4){assert.equal(png.data[k+3],255,'Transparent pixel');if(Math.min(...png.data.subarray(k,k+3))<215)colored++;}
  const coverage=colored/(png.width*png.height);assert(coverage>.25,`Blank or wrong crop: frame ${i}`);minCoverage=Math.min(minCoverage,coverage);renders++;
 }
 previews.push(`<g transform="translate(${i%5*184} ${Math.floor(i/5)*170})"><rect width="180" height="166" fill="#fff" stroke="#6d775f"/><svg y="2" width="180" height="150" viewBox="0 0 307.2 256">${art.innerHTML}</svg><text x="7" y="162" font-family="sans-serif" font-size="10">Frame ${i}</text></g>`);
}
const before=cat.tile.getAttribute('viewBox');for(const bad of [-1,30,NaN,1.5,'7'])cat.frame(bad);assert.equal(cat.tile.getAttribute('viewBox'),before);assert.equal(el.querySelectorAll('image').length,1);
const output=path.join(__dirname,'../../qa');fs.mkdirSync(output,{recursive:true});fs.writeFileSync(path.join(output,'frame-grid.png'),new Resvg(`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="920" height="1020"><rect width="100%" height="100%" fill="#dce2d7"/>${previews.join('')}</svg>`).render().asPng());
console.log(`PASS ${renders} rendered portraits: 30 frames at 100/125/150/200% widths, no blank frames or transparent pixels; minimum artwork coverage ${(minCoverage*100).toFixed(1)}%.`);dom.window.close();
