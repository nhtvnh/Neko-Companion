const {test}=require('node:test');const assert=require('node:assert/strict');
const design=require('../renderer/sound-design.js');
test('chatter remains bounded, finite, and schedules valid mouth frames',()=>{
 const sound=design.chatter('Hello world! '.repeat(500),'excited');
 assert(sound.duration>1&&sound.duration<18);assert(sound.syllables.length<=32);
 let peak=0;for(const sample of sound.samples){assert(Number.isFinite(sample));peak=Math.max(peak,Math.abs(sample));}
 assert(peak>.1&&peak<.95);assert(sound.syllables.every(s=>s.start>=0&&s.start+s.duration<=sound.duration&&[7,9].includes(s.frame)));
});
test('emotion effects are distinct, short, and free of clipping',()=>{
 const fingerprints=new Set();for(const name of ['happy','curious','surprised','sad','thinking','pet','saved','error']){const s=design.effect(name);assert(s.duration<1);let peak=0;for(const v of s.samples){assert(Number.isFinite(v));peak=Math.max(peak,Math.abs(v));}assert(peak<.95&&peak>.1);fingerprints.add(Buffer.from(s.samples.buffer).toString('base64'));}assert.equal(fingerprints.size,8);
});
test('same text is reproducible and emotions change chatter pitch',()=>{const a=design.chatter('Hi there','happy'),b=design.chatter('Hi there','sad');assert.deepEqual(a.samples,design.chatter('Hi there','happy').samples);assert.notDeepEqual(a.samples,b.samples);});

test('talking holds readable poses, avoids short closed-mouth flashes, and closes during pauses',()=>{
 for(const text of ['Hello there, human. Let us relax! A little story?', 'Welcome to the river '.repeat(50), '!?'.repeat(300)]){
  const s=design.chatter(text,'happy');assert(s.syllables.every(x=>x.duration>=.2));
  assert.equal(design.mouthFrameAt(s,-1),5);assert.equal(design.mouthFrameAt(s,s.duration),5);
  for(let i=1;i<s.mouthCues.length;i++){const a=s.mouthCues[i-1],b=s.mouthCues[i];if(i>1)assert(b.start-a.start>=.18-1e-6,'No sub-180ms pose flashes');assert.notEqual(a.frame,b.frame);}
  for(let i=0;i<s.syllables.length-1;i++){const a=s.syllables[i],b=s.syllables[i+1],end=a.start+a.duration,gap=b.start-end;if(gap<.22)assert.notEqual(design.mouthFrameAt(s,end+gap/2),5);else assert.equal(design.mouthFrameAt(s,end+gap/2),5);}
 }
});
