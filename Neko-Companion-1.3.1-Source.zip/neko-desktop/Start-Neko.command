#!/bin/bash
set -e
cd -- "$(dirname -- "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js LTS from https://nodejs.org, then run this file again."
  read -r -p "Press Enter to close."
  exit 1
fi
if [ ! -f node_modules/electron/path.txt ]; then
  echo "Installing Neko. The first run needs an internet connection..."
  npm install --no-audit --no-fund
fi
npm start
